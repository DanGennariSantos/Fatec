﻿namespace PMatriz
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCalcularMedia = new System.Windows.Forms.Button();
            this.btnInverter = new System.Windows.Forms.Button();
            this.btnArmazem = new System.Windows.Forms.Button();
            this.btnListaAlunos = new System.Windows.Forms.Button();
            this.btnCalcularCaracteres = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnCalcularMedia
            // 
            this.btnCalcularMedia.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcularMedia.Location = new System.Drawing.Point(58, 212);
            this.btnCalcularMedia.Name = "btnCalcularMedia";
            this.btnCalcularMedia.Size = new System.Drawing.Size(156, 125);
            this.btnCalcularMedia.TabIndex = 0;
            this.btnCalcularMedia.Text = "Ex. 5 - Calcular Médias";
            this.btnCalcularMedia.UseVisualStyleBackColor = true;
            this.btnCalcularMedia.Click += new System.EventHandler(this.BtnCalcularMedia_Click);
            // 
            // btnInverter
            // 
            this.btnInverter.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInverter.Location = new System.Drawing.Point(58, 30);
            this.btnInverter.Name = "btnInverter";
            this.btnInverter.Size = new System.Drawing.Size(156, 125);
            this.btnInverter.TabIndex = 1;
            this.btnInverter.Text = "Ex.1 - Inverter";
            this.btnInverter.UseVisualStyleBackColor = true;
            this.btnInverter.Click += new System.EventHandler(this.BtnInverter_Click);
            // 
            // btnArmazem
            // 
            this.btnArmazem.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnArmazem.Location = new System.Drawing.Point(269, 30);
            this.btnArmazem.Name = "btnArmazem";
            this.btnArmazem.Size = new System.Drawing.Size(156, 125);
            this.btnArmazem.TabIndex = 2;
            this.btnArmazem.Text = "Ex.2 - Armazém";
            this.btnArmazem.UseVisualStyleBackColor = true;
            // 
            // btnListaAlunos
            // 
            this.btnListaAlunos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnListaAlunos.Location = new System.Drawing.Point(483, 30);
            this.btnListaAlunos.Name = "btnListaAlunos";
            this.btnListaAlunos.Size = new System.Drawing.Size(156, 125);
            this.btnListaAlunos.TabIndex = 3;
            this.btnListaAlunos.Text = "Ex.4 - Lista Alunos";
            this.btnListaAlunos.UseVisualStyleBackColor = true;
            this.btnListaAlunos.Click += new System.EventHandler(this.BtnListaAlunos_Click);
            // 
            // btnCalcularCaracteres
            // 
            this.btnCalcularCaracteres.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcularCaracteres.Location = new System.Drawing.Point(269, 212);
            this.btnCalcularCaracteres.Name = "btnCalcularCaracteres";
            this.btnCalcularCaracteres.Size = new System.Drawing.Size(156, 125);
            this.btnCalcularCaracteres.TabIndex = 4;
            this.btnCalcularCaracteres.Text = "Ex. 6 - Calcular Caracteres";
            this.btnCalcularCaracteres.UseVisualStyleBackColor = true;
            this.btnCalcularCaracteres.Click += new System.EventHandler(this.BtnCalcularCaracteres_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(709, 403);
            this.Controls.Add(this.btnCalcularCaracteres);
            this.Controls.Add(this.btnListaAlunos);
            this.Controls.Add(this.btnArmazem);
            this.Controls.Add(this.btnInverter);
            this.Controls.Add(this.btnCalcularMedia);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCalcularMedia;
        private System.Windows.Forms.Button btnInverter;
        private System.Windows.Forms.Button btnArmazem;
        private System.Windows.Forms.Button btnListaAlunos;
        private System.Windows.Forms.Button btnCalcularCaracteres;
    }
}

