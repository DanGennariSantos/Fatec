﻿namespace PLacos
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPalind = new System.Windows.Forms.TextBox();
            this.btnPalind = new System.Windows.Forms.Button();
            this.lblFrase = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtPalind
            // 
            this.txtPalind.Location = new System.Drawing.Point(36, 40);
            this.txtPalind.MaxLength = 50;
            this.txtPalind.Name = "txtPalind";
            this.txtPalind.Size = new System.Drawing.Size(357, 20);
            this.txtPalind.TabIndex = 0;
            // 
            // btnPalind
            // 
            this.btnPalind.Location = new System.Drawing.Point(128, 81);
            this.btnPalind.Name = "btnPalind";
            this.btnPalind.Size = new System.Drawing.Size(169, 53);
            this.btnPalind.TabIndex = 1;
            this.btnPalind.Text = "Checar Palíndromo";
            this.btnPalind.UseVisualStyleBackColor = true;
            this.btnPalind.Click += new System.EventHandler(this.btnPalind_Click);
            // 
            // lblFrase
            // 
            this.lblFrase.AutoSize = true;
            this.lblFrase.Location = new System.Drawing.Point(36, 13);
            this.lblFrase.Name = "lblFrase";
            this.lblFrase.Size = new System.Drawing.Size(125, 13);
            this.lblFrase.TabIndex = 2;
            this.lblFrase.Text = "Digite a palavra ou frase:";
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(446, 223);
            this.Controls.Add(this.lblFrase);
            this.Controls.Add(this.btnPalind);
            this.Controls.Add(this.txtPalind);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtPalind;
        private System.Windows.Forms.Button btnPalind;
        private System.Windows.Forms.Label lblFrase;
    }
}