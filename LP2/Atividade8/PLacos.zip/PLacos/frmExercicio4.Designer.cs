﻿namespace PLacos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblNome = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.lblCargo = new System.Windows.Forms.Label();
            this.txtMatricula = new System.Windows.Forms.TextBox();
            this.lblMatricula = new System.Windows.Forms.Label();
            this.txtProducao = new System.Windows.Forms.TextBox();
            this.lblProducao = new System.Windows.Forms.Label();
            this.txtGratif = new System.Windows.Forms.TextBox();
            this.lblGratif = new System.Windows.Forms.Label();
            this.btnCalcSalBruto = new System.Windows.Forms.Button();
            this.cmbBoxCargo = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNome.Location = new System.Drawing.Point(22, 23);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(51, 16);
            this.lblNome.TabIndex = 0;
            this.lblNome.Text = "Nome: ";
            this.lblNome.Click += new System.EventHandler(this.lblNome_Click);
            // 
            // txtNome
            // 
            this.txtNome.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNome.Location = new System.Drawing.Point(113, 20);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(100, 22);
            this.txtNome.TabIndex = 1;
            this.txtNome.TextChanged += new System.EventHandler(this.txtNome_TextChanged);
            // 
            // lblCargo
            // 
            this.lblCargo.AutoSize = true;
            this.lblCargo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCargo.Location = new System.Drawing.Point(22, 65);
            this.lblCargo.Name = "lblCargo";
            this.lblCargo.Size = new System.Drawing.Size(48, 16);
            this.lblCargo.TabIndex = 2;
            this.lblCargo.Text = "Cargo:";
            // 
            // txtMatricula
            // 
            this.txtMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMatricula.Location = new System.Drawing.Point(113, 107);
            this.txtMatricula.Name = "txtMatricula";
            this.txtMatricula.Size = new System.Drawing.Size(100, 22);
            this.txtMatricula.TabIndex = 3;
            // 
            // lblMatricula
            // 
            this.lblMatricula.AutoSize = true;
            this.lblMatricula.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMatricula.Location = new System.Drawing.Point(22, 110);
            this.lblMatricula.Name = "lblMatricula";
            this.lblMatricula.Size = new System.Drawing.Size(68, 16);
            this.lblMatricula.TabIndex = 4;
            this.lblMatricula.Text = "Matrícula: ";
            // 
            // txtProducao
            // 
            this.txtProducao.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProducao.Location = new System.Drawing.Point(413, 17);
            this.txtProducao.Name = "txtProducao";
            this.txtProducao.Size = new System.Drawing.Size(100, 22);
            this.txtProducao.TabIndex = 4;
            // 
            // lblProducao
            // 
            this.lblProducao.AutoSize = true;
            this.lblProducao.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProducao.Location = new System.Drawing.Point(322, 20);
            this.lblProducao.Name = "lblProducao";
            this.lblProducao.Size = new System.Drawing.Size(73, 16);
            this.lblProducao.TabIndex = 6;
            this.lblProducao.Text = "Produção: ";
            // 
            // txtGratif
            // 
            this.txtGratif.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGratif.Location = new System.Drawing.Point(413, 59);
            this.txtGratif.Name = "txtGratif";
            this.txtGratif.Size = new System.Drawing.Size(100, 22);
            this.txtGratif.TabIndex = 5;
            // 
            // lblGratif
            // 
            this.lblGratif.AutoSize = true;
            this.lblGratif.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGratif.Location = new System.Drawing.Point(322, 62);
            this.lblGratif.Name = "lblGratif";
            this.lblGratif.Size = new System.Drawing.Size(86, 16);
            this.lblGratif.TabIndex = 10;
            this.lblGratif.Text = "Gratificação: ";
            // 
            // btnCalcSalBruto
            // 
            this.btnCalcSalBruto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcSalBruto.Location = new System.Drawing.Point(217, 166);
            this.btnCalcSalBruto.Name = "btnCalcSalBruto";
            this.btnCalcSalBruto.Size = new System.Drawing.Size(115, 52);
            this.btnCalcSalBruto.TabIndex = 12;
            this.btnCalcSalBruto.Text = "Calcular Salário Bruto";
            this.btnCalcSalBruto.UseVisualStyleBackColor = true;
            this.btnCalcSalBruto.Click += new System.EventHandler(this.btnCalcSalBruto_Click);
            // 
            // cmbBoxCargo
            // 
            this.cmbBoxCargo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbBoxCargo.FormattingEnabled = true;
            this.cmbBoxCargo.Items.AddRange(new object[] {
            "Soldador",
            "Operador",
            "Auxiliar"});
            this.cmbBoxCargo.Location = new System.Drawing.Point(113, 61);
            this.cmbBoxCargo.Name = "cmbBoxCargo";
            this.cmbBoxCargo.Size = new System.Drawing.Size(100, 24);
            this.cmbBoxCargo.TabIndex = 2;
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(563, 265);
            this.Controls.Add(this.cmbBoxCargo);
            this.Controls.Add(this.btnCalcSalBruto);
            this.Controls.Add(this.txtGratif);
            this.Controls.Add(this.lblGratif);
            this.Controls.Add(this.txtProducao);
            this.Controls.Add(this.lblProducao);
            this.Controls.Add(this.txtMatricula);
            this.Controls.Add(this.lblMatricula);
            this.Controls.Add(this.lblCargo);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.lblNome);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.Load += new System.EventHandler(this.frmExercicio4_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.Label lblCargo;
        private System.Windows.Forms.TextBox txtMatricula;
        private System.Windows.Forms.Label lblMatricula;
        private System.Windows.Forms.TextBox txtProducao;
        private System.Windows.Forms.Label lblProducao;
        private System.Windows.Forms.TextBox txtGratif;
        private System.Windows.Forms.Label lblGratif;
        private System.Windows.Forms.Button btnCalcSalBruto;
        private System.Windows.Forms.ComboBox cmbBoxCargo;
    }
}