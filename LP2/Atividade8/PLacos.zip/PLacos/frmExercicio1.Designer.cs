﻿namespace PLacos
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rchTxtTexto = new System.Windows.Forms.RichTextBox();
            this.lblFrase = new System.Windows.Forms.Label();
            this.btnEspaco = new System.Windows.Forms.Button();
            this.btnR = new System.Windows.Forms.Button();
            this.btnRep = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rchTxtTexto
            // 
            this.rchTxtTexto.Location = new System.Drawing.Point(56, 37);
            this.rchTxtTexto.Name = "rchTxtTexto";
            this.rchTxtTexto.Size = new System.Drawing.Size(431, 96);
            this.rchTxtTexto.TabIndex = 0;
            this.rchTxtTexto.Text = "";
            this.rchTxtTexto.TextChanged += new System.EventHandler(this.RchTxtTexto_TextChanged);
            // 
            // lblFrase
            // 
            this.lblFrase.AutoSize = true;
            this.lblFrase.Location = new System.Drawing.Point(56, 18);
            this.lblFrase.Name = "lblFrase";
            this.lblFrase.Size = new System.Drawing.Size(36, 13);
            this.lblFrase.TabIndex = 1;
            this.lblFrase.Text = "Frase:";
            // 
            // btnEspaco
            // 
            this.btnEspaco.Location = new System.Drawing.Point(56, 178);
            this.btnEspaco.Name = "btnEspaco";
            this.btnEspaco.Size = new System.Drawing.Size(121, 60);
            this.btnEspaco.TabIndex = 2;
            this.btnEspaco.Text = "Contar Espaços em Branco";
            this.btnEspaco.UseVisualStyleBackColor = true;
            this.btnEspaco.Click += new System.EventHandler(this.BtnEspaco_Click);
            // 
            // btnR
            // 
            this.btnR.Location = new System.Drawing.Point(211, 178);
            this.btnR.Name = "btnR";
            this.btnR.Size = new System.Drawing.Size(121, 60);
            this.btnR.TabIndex = 3;
            this.btnR.Text = "Contar Rs";
            this.btnR.UseVisualStyleBackColor = true;
            this.btnR.Click += new System.EventHandler(this.BtnR_Click);
            // 
            // btnRep
            // 
            this.btnRep.Location = new System.Drawing.Point(364, 178);
            this.btnRep.Name = "btnRep";
            this.btnRep.Size = new System.Drawing.Size(121, 60);
            this.btnRep.TabIndex = 4;
            this.btnRep.Text = "Contar Repetidos";
            this.btnRep.UseVisualStyleBackColor = true;
            this.btnRep.Click += new System.EventHandler(this.BtnRep_Click);
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(566, 299);
            this.Controls.Add(this.btnRep);
            this.Controls.Add(this.btnR);
            this.Controls.Add(this.btnEspaco);
            this.Controls.Add(this.lblFrase);
            this.Controls.Add(this.rchTxtTexto);
            this.Name = "frmExercicio1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RichTextBox rchTxtTexto;
        private System.Windows.Forms.Label lblFrase;
        private System.Windows.Forms.Button btnEspaco;
        private System.Windows.Forms.Button btnR;
        private System.Windows.Forms.Button btnRep;
    }
}