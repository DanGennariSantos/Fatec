﻿
namespace ListaEstudo
{
    partial class FormEx38
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lboxResultado = new System.Windows.Forms.ListBox();
            this.btnCalcTotal = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lboxResultado
            // 
            this.lboxResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lboxResultado.FormattingEnabled = true;
            this.lboxResultado.ItemHeight = 16;
            this.lboxResultado.Location = new System.Drawing.Point(51, 37);
            this.lboxResultado.Name = "lboxResultado";
            this.lboxResultado.Size = new System.Drawing.Size(439, 212);
            this.lboxResultado.TabIndex = 0;
            // 
            // btnCalcTotal
            // 
            this.btnCalcTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcTotal.Location = new System.Drawing.Point(216, 273);
            this.btnCalcTotal.Name = "btnCalcTotal";
            this.btnCalcTotal.Size = new System.Drawing.Size(105, 39);
            this.btnCalcTotal.TabIndex = 1;
            this.btnCalcTotal.Text = "Calcular Total";
            this.btnCalcTotal.UseVisualStyleBackColor = true;
            this.btnCalcTotal.Click += new System.EventHandler(this.btnCalcTotal_Click);
            // 
            // FormEx38
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(542, 355);
            this.Controls.Add(this.btnCalcTotal);
            this.Controls.Add(this.lboxResultado);
            this.Name = "FormEx38";
            this.Text = "FormEx38";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lboxResultado;
        private System.Windows.Forms.Button btnCalcTotal;
    }
}